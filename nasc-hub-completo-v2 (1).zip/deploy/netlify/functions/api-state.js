// NascHUB API v0.2 — estado persistido (@netlify/blobs 11.x, API de stores), escopo por usuário
import { getStore } from '@netlify/blobs';
let _st; const store=()=>{_st=_st||getStore('naschub');return _st;};
const KEY='naschub-state.json';
const H={'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type'};
function scopeKey(u){
  const base=String(u||'').trim().toLowerCase();
  if(!base)return KEY;
  const local=base.split('@')[0].replace(/[^a-z0-9]/g,'').slice(0,40)||'user';
  return 'naschub-state.'+local+'.json';
}
async function readTxt(k){try{return await store().get(k);}catch(e){return null;}}
async function writeTxt(k,s){await store().set(k,s);}
export const handler=async(req)=>{
  if(req.method==='OPTIONS')return{statusCode:204,headers:H,body:''};
  try{
    if(req.method==='GET'){
      const k=scopeKey(req.query&&req.query.user);
      const t=await readTxt(k);
      const d=t?JSON.parse(t):null;
      return{statusCode:200,headers:H,body:JSON.stringify(d||{empty:true})};
    }
    if(req.method==='POST'){
      const {data,user}=JSON.parse(req.body||'{}');
      if(!data||typeof data!=='object')return{statusCode:400,headers:H,body:JSON.stringify({error:'payload'})};
      const k=scopeKey(user);
      const ot=await readTxt(k);
      const old=ot?JSON.parse(ot):{v:0};
      const rec={v:(old.v||0)+1,ts:Date.now(),user:String(user||'guest'),data};
      await writeTxt(k,JSON.stringify(rec));
      return{statusCode:200,headers:H,body:JSON.stringify({ok:true,v:rec.v,ts:rec.ts,scope:k})};
    }
    return{statusCode:405,headers:H,body:JSON.stringify({error:'method'})};
  }catch(e){return{statusCode:500,headers:H,body:JSON.stringify({error:String((e&&e.message)||e)})};}
};
