NASC HUB — PACOTE DE PRODUCÇÃO v2 (2026-10-07)
================================================
O QUE MUDOU EM RELACAO AO ZIP ANTERIOR
- As funcoes api-state e api-secrets foram PORTADAS para a API de stores do
  @netlify/blobs 11.x (getStore('naschub').get/set). MOTIVO: o npm atual
  (11.1.3+) removeu getBlob/putBlob — qualquer rebuild com a fonte antiga
  quebra com "does not provide an export named 'getBlob'" (comprovado em
  Node 22 real, ver HANDOFF-PROD.md na caixa completa).
- Fontes validadas: Node v22.14.0 + suíte local-test.mjs (caixa completa)
  com round-trip REAL na API de blobs da Netlify — 8/8 checks verdes.

COMO FAZER O DROP (mesmo fluxo do deploy das 09:01 que deu certo)
1. app.netlify.com (conta melzaoyago@gmail.com) → projeto naschub → Deploys
2. Arraste a PASTA deste zip (a raiz tem index.html + netlify.toml + netlify/)
3. Aguarde o build (o runner faz npm install do @netlify/blobs atual — agora
   compatível) → deve registrar 4 funções com rotas /api/*
4. Validar: POST /api/login (demo) → 200 · GET /api/state?user=... → ok ·
   POST /api/integrations-test {id:'porto'} → simulado:true

PLANO B (se o deploy registrar 0 funções = build não rodou)
- Mover o conteúdo de netlify/functions-zips/ PARA dentro de netlify/functions/
  (apagando os .js antes) e re-arrastar. Os zips já são pré-compilados e
  autocontidos (node_modules do @netlify/blobs 11.1.3 embutido, package.json
  type:module na raiz).

NOTA DE CONTINUIDADE DE DADOS
- O novo namespace é o store nomeado 'naschub'. Dados gravados pela versão
  antiga (API getBlob = store padrão do site) NÃO aparecem no novo store.
  Seed de demonstração a regravar pós-deploy: estado do tenant nascor e
  segredo porto ••••••4321 (via POST /api/state e /api/secrets).
