NASC HUB — HANDOFF DE PRODUÇÃO (substitui o §8 do handoff original)
gerado em 2026-10-07 11:38 UTC · sessão de recuperação 2026-10-07
====================================================================

PRODUÇÃO CANÔNICA
- URL        : https://naschub.netlify.app  (subdominio recuperado hoje)
- Site id    : 4289e680-871e-4121-9006-1ac18272fbce
- Conta      : melzaoyago@gmail.com  (site antigo, conta yagomel180795, APAGADO em 2026-10-07)
- Token      : nfp_Diay5J4sZPLrjrrFTJDwW13UGtBRcHfe1c21
               lê site · publica (published_deploy_id) · NAO cria deploys (créditos) · NAO grava env (404)
- Deploy no ar: 6ac60a63fa164c00ac423838 (runner 09:01Z; funções c/ rotas /api/* e deps vendadas)
- Validação  : bateria de 26 checks verde (~10:35Z): login 200/401/Bearer · state round-trip + LWW ·
               segredos gravar/máscara ••••••last4/decrypt c/ Bearer · integrations-test porto/sul/qover
               simulado:true · bundle motion-v2 completo (nh-breathe/viewIn/sheen nos CTAs)

PAREDE SSO (causa raiz do dia)
- Site nasceu com sso_login=true context=all → tudo 401 "Login Redirect".
- Resolvido por API: PUT /sites/{id} {"sso_login": false}. Se voltar: Settings → Access control.

CRÉDITOS (bloqueio nº 1 p/ o próximo deploy)
- POST /sites/{id}/deploys → 403 "Account credit usage exceeded - new deploys are blocked
  until credits are added". Deploys NOVOS bloqueados até créditos renovarem/entrarem.
  Servindo do que está no ar NÃO é afetado. Ver: Billing → Credits/Usage (conta melzaoyago).

NH_SECRET
- Inexistente no site novo; funções rodam com default 'naschub-dev' (autoconsistente p/ demo).
- Criar no painel: Settings → Environment variables → NH_SECRET (production + deploy-preview),
  valor em NH_SECRET.txt (64 chars). Se criar depois: regravar seeds de segredo (cifra muda).
- API de env retorna 404 com este token (escopo/plano).

MIGRAÇÃO @netlify/blobs 11.x (a mina desarmada)
- npm latest (11.1.3+) REMOUEU getBlob/putBlob → rebuild com fonte antiga quebra
  ("does not provide an export named getBlob", comprovado em Node 22 real).
- Fontes portadas NESTE pacote: deploy/netlify/functions/api-state.js e api-secrets.js
  (store nomeado 'naschub', getStore('naschub').get/set lazy, MESMOS nomes de chave).
- Prova: testes/local/local-test.mjs + Node v22 (arena /workspace/node/n22/bin/node) contra a
  API REAL de blobs → 8/8 verdes. Zips pré-compilados de fallback: naschub-netlify-v2.zip.
- REGRA: a partir de agora TODO deploy sai das fontes/fontes-portadas deste pacote.

CONTINUIDADE PÓS-REDEPLOY
- Store legado (API antiga, no ar) ≠ store nomeado 'naschub' (novas fontes) → regravar seeds:
  1) POST /api/state?user=yago@nascor.com.br  {"user":"yago@nascor.com.br","data":{...}}
  2) POST /api/secrets {"items":[{"id":"porto","segId":"porto","adapter":"API_PARCIAL","secret":"..."}]}

CHECKLIST
[ ] Yago: créditos OK no Billing (bloqueio p/ drop)
[ ] Yago: drop do naschub-netlify-v2.zip no fluxo do runner (4 funções c/ rotas)
[ ] IA: bateria 26 + re-seed pós-drop
[ ] IA: prova cold start (marcador 1791373122 gravado agora; reler >15 min depois)
[ ] Yago: passada visual 2 navegadores (chips + LWW) — 5 min
[ ] IA/backlog: clones Tokio/HDI · adaptador real Porto · export CSV/PDF · notificações ≤30d · multi-corretora · página preços

MUDANÇAS DE 2026-10-07 (operação)
- Topbar opaca (#0E1520, sem blur) · menu lateral 100% colapsável (grupos minimizáveis) · CARTEIRA em 1º
- KPIs home: "comissão estimada" FORA; entraram Parcelas pendentes (148 · R$ 61.340) e Emissão 30d (96)
- Área FINANCEIRA nova (/#/financeira): comissões por contrato, fluxo 12m, próximos recebimentos (anual÷12), régua de cobrança
- Home: quadros de comissão só para ADMIN (demais perfis veem card trancado c/ cadeado)
- Head da home = apenas HOME (Fraunces 23px + filete em gradiente aurora mint→violeta), sem título/breadcrumb; demais módulos preservados
- Validação: node --check rc0 + jsdom 21/21 (domtest/harness.mjs; operador semeado via shim p/ storage)

MUDANÇA DE 2026-10-07 (home)
- Landing/página inicial REMOVIDA do app: home (#/) e toda rota sem auth = tela de LOGIN.
  Rotas de marketing (#feat/#como/#planos e CTAs "Criar conta") somem junto. ?demo=1 segue logando direto.
  Marca clicável aponta p/ #/ ; logout cai em #/login. Validação: jsdom 11/11 (harness em domtest/harness.mjs na arena).

DEEP-LINKS
?demo=1 · ?demo=1&ingest=sul|porto · ?birth=<id> · ?importall=1&stay=1 · #/selftest · deck ?s=N
