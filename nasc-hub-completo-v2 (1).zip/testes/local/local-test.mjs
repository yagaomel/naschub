
process.env.NETLIFY_SITE_ID = '4289e680-871e-4121-9006-1ac18272fbce';
process.env.NETLIFY_AUTH_TOKEN = 'nfp_Diay5J4sZPLrjrrFTJDwW13UGtBRcHfe1c21';
process.env.NETLIFY_REGION='us-east-2';
const B = await import('/workspace/build/stage/node_modules/@netlify/blobs/dist/main.js');
B.setEnvironmentContext({siteID:'4289e680-871e-4121-9006-1ac18272fbce', token:'nfp_Diay5J4sZPLrjrrFTJDwW13UGtBRcHfe1c21', primaryRegion:'us-east-2'});
const call = async (mod, method, q, body, headers) => {
  const h = await mod.handler({method, query: q||{}, body: body?JSON.stringify(body):'', headers: headers||{}});
  let j=null; try{ j = JSON.parse(h.body); }catch(e){}
  return {s:h.statusCode, j, raw:h.body};
};
const load = async (n) => await import('/workspace/build/stg-' + n + '/index.js');
try {
  const login = await load('api-login');
  let r = await call(login,'POST',null,{email:'yago@nascor.com.br',password:'nascor@23'});
  console.log('login POST      ', r.s, r.j&&r.j.ok?'ok+token':'FALHA '+JSON.stringify(r.j));
  const tok = r.j.token;
  r = await call(login,'GET',null,null,{authorization:'Bearer '+tok});
  console.log('login GET Bearer', r.s, r.j&&r.j.user?r.j.user.email+' '+r.j.user.role:'FALHA');
  const state = await load('api-state');
  const U='localtest@nascor.com.br';
  r = await call(state,'GET',{user:U});
  console.log('state GET inicial', r.s, r.j&&('empty' in r.j||'v' in r.j)?'ok':'FALHA '+JSON.stringify(r.j));
  r = await call(state,'POST',{user:U},{data:{prova:'local-zip-test'},user:U});
  console.log('state POST      ', r.s, r.j&&r.j.ok?('ok v'+r.j.v+' scope='+r.j.scope):'FALHA '+JSON.stringify(r.j));
  r = await call(state,'GET',{user:U});
  console.log('state roundtrip ', r.s, r.j&&r.j.data&&r.j.data.prova==='local-zip-test'?'ok':'FALHA');
  const sec = await load('api-secrets');
  r = await call(sec,'POST',null,{items:[{id:'localtest',segId:'localtest',adapter:'MOCK',secret:'ZIPTEST-9876'}]});
  console.log('secrets gravar  ', r.s, r.j&&r.j.saved===1?'ok':'FALHA '+JSON.stringify(r.j));
  r = await call(sec,'GET');
  const it=(r.j.items||[]).find(i=>i.id==='localtest');
  console.log('secrets mascara ', r.s, it&&it.masked==='••••••9876'&&it.hasSecret?'ok':'FALHA '+JSON.stringify(it));
  r = await call(sec,'POST',null,{mode:'decrypt',id:'localtest'},{authorization:'Bearer '+tok});
  console.log('secrets decrypt ', r.s, r.j&&r.j.plain==='ZIPTEST-9876'?'ok':'FALHA '+JSON.stringify(r.j));
  const ite = await load('api-integrations-test');
  r = await call(ite,'POST',null,{id:'porto',adapter:'API_PARCIAL'});
  console.log('integrations-test', r.s, r.j&&r.j.simulado===true?'ok':'FALHA');
  console.log('LOCAL-SUMMARY OK: zips carregam (ESM + node_modules vendado) e fazem round-trip real na API de blobs');
} catch(e){
  console.log('LOCAL-ERROR:', e && e.stack ? e.stack.split('\n').slice(0,8).join(' | ') : e);
}
